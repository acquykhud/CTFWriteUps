#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, const char *argv[])
{
    int Delta = 0;
    if (argc >= 2)
        Delta = atoi(argv[1]);
    srand(time(0) - Delta);
    for (int i = 0; i < 30; ++i)
        printf("%d\n", rand() & 0xF);
}